var router = require('express').Router();
const authController = require('../controllers/authController');
/* GET users listing. */

router.post("/tokens", authController.create);
//router.get("/:id", campaignController.getUserById);

module.exports = router;
